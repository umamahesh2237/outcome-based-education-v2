const { SubjectiveMapping, SubjectiveMarks } = require('../models/SubjectiveMapping');

// Controller to save subjective mapping
exports.saveMapping = async (req, res) => {
  const { regulation, semester, academicYear, courseName, facultyName, mappings } = req.body;

  if (!regulation || !semester || !academicYear || !courseName || !facultyName || !mappings) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    // Check if mapping already exists
    let mapping = await SubjectiveMapping.findOne({
      regulation,
      semester,
      academicYear,
      courseName,
      facultyName
    });

    if (mapping) {
      // Update existing mapping
      mapping.mappings = mappings;
      await mapping.save();
    } else {
      // Create new mapping
      mapping = new SubjectiveMapping({
        regulation,
        semester,
        academicYear,
        courseName,
        facultyName,
        mappings
      });
      await mapping.save();
    }

    res.status(200).json({ message: 'Subjective mapping saved successfully' });
  } catch (error) {
    console.error('Error saving subjective mapping:', error);
    res.status(500).json({ error: 'Failed to save mapping', details: error.message });
  }
};

// Controller to fetch subjective mapping
exports.fetchMapping = async (req, res) => {
  const { regulation, semester, academicYear, courseName, facultyName } = req.query;

  if (!regulation || !semester || !academicYear || !courseName || !facultyName) {
    return res.status(400).json({ message: 'All filters are required' });
  }

  try {
    const mapping = await SubjectiveMapping.findOne({
      regulation,
      semester,
      academicYear,
      courseName,
      facultyName
    });

    if (!mapping) {
      return res.status(404).json({ message: 'No mapping found' });
    }

    res.status(200).json(mapping);
  } catch (error) {
    console.error('Error fetching subjective mapping:', error);
    res.status(500).json({ error: 'Failed to fetch mapping', details: error.message });
  }
};

// Controller to save subjective marks
exports.saveMarks = async (req, res) => {
  const { regulation, semester, academicYear, courseName, facultyName, marks } = req.body;

  if (!regulation || !semester || !academicYear || !courseName || !facultyName || !marks) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    // Check if marks already exist
    let marksDoc = await SubjectiveMarks.findOne({
      regulation,
      semester,
      academicYear,
      courseName,
      facultyName
    });

    if (marksDoc) {
      // Update existing marks
      marksDoc.marks = marks;
      await marksDoc.save();
    } else {
      // Create new marks document
      marksDoc = new SubjectiveMarks({
        regulation,
        semester,
        academicYear,
        courseName,
        facultyName,
        marks
      });
      await marksDoc.save();
    }

    res.status(200).json({ message: 'Subjective marks saved successfully' });
  } catch (error) {
    console.error('Error saving subjective marks:', error);
    res.status(500).json({ error: 'Failed to save marks', details: error.message });
  }
};

// Controller to fetch subjective marks
exports.fetchMarks = async (req, res) => {
  const { regulation, semester, academicYear, courseName, facultyName } = req.query;

  if (!regulation || !semester || !academicYear || !courseName || !facultyName) {
    return res.status(400).json({ message: 'All filters are required' });
  }

  try {
    const marksDoc = await SubjectiveMarks.findOne({
      regulation,
      semester,
      academicYear,
      courseName,
      facultyName
    });

    if (!marksDoc) {
      return res.status(404).json({ message: 'No marks found' });
    }

    res.status(200).json(marksDoc);
  } catch (error) {
    console.error('Error fetching subjective marks:', error);
    res.status(500).json({ error: 'Failed to fetch marks', details: error.message });
  }
};