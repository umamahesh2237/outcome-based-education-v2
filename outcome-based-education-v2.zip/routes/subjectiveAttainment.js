const express = require('express');
const router = express.Router();
const subjectiveMappingController = require('../controllers/subjectiveMappingController');

// Routes for subjective mapping
router.post('/mapping/save', subjectiveMappingController.saveMapping);
router.get('/mapping/fetch', subjectiveMappingController.fetchMapping);

// Routes for subjective marks
router.post('/marks/save', subjectiveMappingController.saveMarks);
router.get('/marks/fetch', subjectiveMappingController.fetchMarks);

module.exports = router;