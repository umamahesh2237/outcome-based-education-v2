const express = require('express');
const router = express.Router();
const endExamController = require('../controllers/endExamController');

// Routes for end exam mapping
router.post('/mapping/save', endExamController.saveMapping);
router.get('/mapping/fetch', endExamController.fetchMapping);

// Routes for end exam marks
router.post('/marks/save', endExamController.saveMarks);
router.get('/marks/fetch', endExamController.fetchMarks);

module.exports = router;