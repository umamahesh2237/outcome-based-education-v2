const express = require('express');
const router = express.Router();
const objectiveMappingController = require('../controllers/objectiveMappingController');

// Routes for objective mapping
router.post('/mapping/save', objectiveMappingController.saveMapping);
router.get('/mapping/fetch', objectiveMappingController.fetchMapping);

// Routes for objective marks
router.post('/marks/save', objectiveMappingController.saveMarks);
router.get('/marks/fetch', objectiveMappingController.fetchMarks);

module.exports = router;