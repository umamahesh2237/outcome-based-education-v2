const mongoose = require('mongoose');

const endExamMappingSchema = new mongoose.Schema({
  regulation: { type: String, required: true },
  academicYear: { type: String, required: true },
  semester: { type: String, required: true },
  courseName: { type: String, required: true },
  facultyName: { type: String, required: true },
  mappings: [{
    questionNumber: { type: String, required: true },
    maxMarks: { type: Number, required: true },
    coMappings: [{
      coNumber: { type: String, required: true },
      value: { type: String, enum: ['1', '-'], default: '-' }
    }]
  }]
}, { timestamps: true });

const endExamMarksSchema = new mongoose.Schema({
  regulation: { type: String, required: true },
  academicYear: { type: String, required: true },
  semester: { type: String, required: true },
  courseName: { type: String, required: true },
  facultyName: { type: String, required: true },
  marks: [{
    rollNo: { type: String, required: true },
    questions: Map,
    totalMarks: { type: Number }
  }]
}, { timestamps: true });

const EndExamMapping = mongoose.model('EndExamMapping', endExamMappingSchema);
const EndExamMarks = mongoose.model('EndExamMarks', endExamMarksSchema);

module.exports = { EndExamMapping, EndExamMarks };