import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

const ObjectiveAttainment = () => {
  const [filters] = useOutletContext();
  const [activeComponent, setActiveComponent] = useState(null);
  const [courseOutcomes, setCourseOutcomes] = useState([]);
  const [mappings, setMappings] = useState([]);
  const [marks, setMarks] = useState([]);
  const [maxMarks, setMaxMarks] = useState({
    objective1: 10,
    objective2: 10
  });
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCourseOutcomes = async () => {
      if (!filters.regulation || !filters.semester || !filters.courseName) return;

      try {
        const response = await axios.get(`${API_BASE_URL}/api/course-outcomes/fetch`, { params: filters });
        const outcomes = Object.entries(response.data)
          .filter(([key, value]) => key !== '_id' && value.trim() !== '')
          .map(([key]) => key);
        setCourseOutcomes(outcomes);

        // Initialize mappings
        const initialMappings = ['Objective-1', 'Objective-2'].map(objectiveNumber => ({
          objectiveNumber,
          maxMarks: 10,
          coMappings: outcomes.map(co => ({
            coNumber: co,
            value: '-'
          }))
        }));
        setMappings(initialMappings);

        // Initialize marks with 300 empty rows
        const initialMarks = Array.from({ length: 300 }, (_, index) => ({
          sNo: index + 1,
          rollNo: '',
          objective1: '',
          objective2: ''
        }));
        setMarks(initialMarks);

        // Fetch existing data if any
        const [mappingRes, marksRes] = await Promise.all([
          axios.get(`${API_BASE_URL}/api/objective-mapping/fetch`, { params: filters }),
          axios.get(`${API_BASE_URL}/api/objective-marks/fetch`, { params: filters })
        ]);

        if (mappingRes.data) {
          setMappings(mappingRes.data.mappings);
        }

        if (marksRes.data) {
          const existingMarks = marksRes.data.marks;
          setMarks(prevMarks => 
            prevMarks.map((row, index) => ({
              ...row,
              ...existingMarks[index]
            }))
          );
        }
      } catch (err) {
        setError('Error fetching data');
        console.error(err);
      }
    };

    fetchCourseOutcomes();
  }, [filters]);

  const handleMappingChange = (objectiveIndex, coIndex, value) => {
    setMappings(prevMappings => {
      const newMappings = [...prevMappings];
      newMappings[objectiveIndex].coMappings[coIndex].value = value;
      return newMappings;
    });
  };

  const handleMarkChange = (index, field, value) => {
    const numValue = value === '' ? '' : Number(value);
    
    // Check if value exceeds max marks
    if (field.startsWith('objective') && numValue !== '') {
      const maxMark = maxMarks[field];
      if (numValue > maxMark) {
        alert(`Value cannot exceed maximum marks (${maxMark})`);
        return;
      }
    }

    setMarks(prevMarks => {
      const newMarks = [...prevMarks];
      newMarks[index] = {
        ...newMarks[index],
        [field]: value
      };
      return newMarks;
    });
  };

  const addMoreRows = () => {
    setMarks(prevMarks => [
      ...prevMarks,
      ...Array.from({ length: 10 }, (_, index) => ({
        sNo: prevMarks.length + index + 1,
        rollNo: '',
        objective1: '',
        objective2: ''
      }))
    ]);
  };

  const saveMapping = async () => {
    try {
      await axios.post(`${API_BASE_URL}/api/objective-mapping/save`, {
        ...filters,
        mappings
      });
      alert('Objective mapping saved successfully!');
    } catch (err) {
      setError('Error saving mapping');
      console.error(err);
    }
  };

  const saveMarks = async () => {
    try {
      const validMarks = marks.filter(m => m.rollNo !== '');
      await axios.post(`${API_BASE_URL}/api/objective-marks/save`, {
        ...filters,
        marks: validMarks
      });
      alert('Objective marks saved successfully!');
    } catch (err) {
      setError('Error saving marks');
      console.error(err);
    }
  };

  const calculateAttainments = () => {
    const validMarks = marks.filter(m => m.rollNo !== '');
    const totalStudents = validMarks.length;
    
    const attainments = ['objective1', 'objective2'].map(objective => {
      const maxMark = maxMarks[objective];
      const target = maxMark * 0.6;
      
      const studentsAttempted = validMarks.filter(m => m[objective] !== '').length;
      const studentsReachingTarget = validMarks.filter(m => 
        m[objective] !== '' && Number(m[objective]) >= target
      ).length;
      
      const attainmentPercentage = studentsAttempted ? 
        (studentsReachingTarget / studentsAttempted) * 100 : 0;
      
      let attainmentLevel = 0;
      if (attainmentPercentage >= 80) attainmentLevel = 3;
      else if (attainmentPercentage >= 70) attainmentLevel = 2;
      else if (attainmentPercentage >= 60) attainmentLevel = 1;

      return {
        target,
        studentsReachingTarget,
        attainmentPercentage: attainmentPercentage.toFixed(2),
        attainmentLevel
      };
    });

    return attainments;
  };

  const renderMappingComponent = () => (
    <div className="table-responsive mt-4">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Objective</th>
            <th>Maximum Marks</th>
            {courseOutcomes.map(co => (
              <th key={co}>{co}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {mappings.map((mapping, objectiveIndex) => (
            <tr key={mapping.objectiveNumber}>
              <td>{mapping.objectiveNumber}</td>
              <td>{mapping.maxMarks}</td>
              {mapping.coMappings.map((coMapping, coIndex) => (
                <td key={coMapping.coNumber}>
                  <select
                    value={coMapping.value}
                    onChange={(e) => handleMappingChange(objectiveIndex, coIndex, e.target.value)}
                    className="form-select form-select-sm"
                  >
                    <option value="-">-</option>
                    <option value="1">1</option>
                  </select>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <button className="submit-button" onClick={saveMapping}>
        <b>Save Mapping</b>
      </button>
    </div>
  );

  const renderMarksComponent = () => (
    <div className="table-responsive mt-4">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>S. No.</th>
            <th>Roll No.</th>
            <th>Objective-1</th>
            <th>Objective-2</th>
          </tr>
          <tr>
            <td colSpan="2">Maximum Marks</td>
            <td>{maxMarks.objective1}</td>
            <td>{maxMarks.objective2}</td>
          </tr>
        </thead>
        <tbody>
          {marks.map((row, index) => (
            <tr key={index}>
              <td>{row.sNo}</td>
              <td>
                <input
                  type="text"
                  value={row.rollNo}
                  onChange={(e) => handleMarkChange(index, 'rollNo', e.target.value)}
                  className="form-control form-control-sm"
                />
              </td>
              <td>
                <input
                  type="number"
                  value={row.objective1}
                  onChange={(e) => handleMarkChange(index, 'objective1', e.target.value)}
                  className="form-control form-control-sm"
                  min="0"
                  max={maxMarks.objective1}
                />
              </td>
              <td>
                <input
                  type="number"
                  value={row.objective2}
                  onChange={(e) => handleMarkChange(index, 'objective2', e.target.value)}
                  className="form-control form-control-sm"
                  min="0"
                  max={maxMarks.objective2}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="d-flex justify-content-between mt-3">
        <button className="add-button" onClick={addMoreRows}>
          <b>Add More Rows</b>
        </button>
        <button className="submit-button" onClick={saveMarks}>
          <b>Save Marks</b>
        </button>
      </div>
    </div>
  );

  const renderAttainmentsComponent = () => {
    const attainments = calculateAttainments();
    
    return (
      <div className="table-responsive mt-4">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th rowSpan="2">Criteria</th>
              <th colSpan="2">Objective Exam Attainment</th>
            </tr>
            <tr>
              <th>Mid-1</th>
              <th>Mid-2</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Target for Objective</td>
              {attainments.map((a, i) => (
                <td key={`target-${i}`}>{a.target}</td>
              ))}
            </tr>
            <tr>
              <td>No. of students reaching target</td>
              {attainments.map((a, i) => (
                <td key={`reaching-${i}`}>{a.studentsReachingTarget}</td>
              ))}
            </tr>
            <tr>
              <td>Attainment %</td>
              {attainments.map((a, i) => (
                <td key={`percentage-${i}`}>{a.attainmentPercentage}%</td>
              ))}
            </tr>
            <tr>
              <td>Attainment Level</td>
              {attainments.map((a, i) => (
                <td key={`level-${i}`}>{a.attainmentLevel}</td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    );
  };

  if (!filters.regulation || !filters.semester || !filters.courseName) {
    return <p className="text-center mt-4">Please select all filters to view objective attainment</p>;
  }

  return (
    <div className="regulation-form mt-4">
      <h5>Objective Attainment</h5>
      <hr />
      {error && <div className="alert alert-danger">{error}</div>}
      <div className="d-flex gap-2 mb-4">
        <button 
          className={`submit-button ${activeComponent === 'mapping' ? 'active' : ''}`}
          onClick={() => setActiveComponent('mapping')}
        >
          <b>Objective Mapping</b>
        </button>
        <button 
          className={`submit-button ${activeComponent === 'marks' ? 'active' : ''}`}
          onClick={() => setActiveComponent('marks')}
        >
          <b>Objective Marks</b>
        </button>
        <button 
          className={`submit-button ${activeComponent === 'attainments' ? 'active' : ''}`}
          onClick={() => setActiveComponent('attainments')}
        >
          <b>Print Objective Attainments</b>
        </button>
      </div>

      {activeComponent === 'mapping' && renderMappingComponent()}
      {activeComponent === 'marks' && renderMarksComponent()}
      {activeComponent === 'attainments' && renderAttainmentsComponent()}
    </div>
  );
};

export default ObjectiveAttainment;