import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

const EndExamAttainment = () => {
  const [filters] = useOutletContext();
  const [activeComponent, setActiveComponent] = useState(null);
  const [courseOutcomes, setCourseOutcomes] = useState([]);
  const [mappings, setMappings] = useState([]);
  const [marks, setMarks] = useState([]);
  const [error, setError] = useState(null);

  // Generate question numbers
  const questionNumbers = [
    ...Array.from({ length: 10 }, (_, i) => `1${String.fromCharCode(97 + i)}`), // 1a to 1j
    ...Array.from({ length: 18 }, (_, i) => `${i + 2}a`), // 2a to 11a
    ...Array.from({ length: 18 }, (_, i) => `${i + 2}b`) // 2b to 11b
  ];

  useEffect(() => {
    const fetchCourseOutcomes = async () => {
      if (!filters.regulation || !filters.semester || !filters.courseName) return;

      try {
        const response = await axios.get(`${API_BASE_URL}/api/course-outcomes/fetch`, { params: filters });
        const outcomes = Object.entries(response.data)
          .filter(([key, value]) => key !== '_id' && value.trim() !== '')
          .map(([key]) => key);
        setCourseOutcomes(outcomes);

        // Initialize mappings
        const initialMappings = questionNumbers.map(qNum => ({
          questionNumber: qNum,
          maxMarks: qNum.startsWith('1') ? 1 : 5,
          coMappings: outcomes.map(co => ({
            coNumber: co,
            value: '-'
          }))
        }));
        setMappings(initialMappings);

        // Initialize marks with 300 empty rows
        const initialMarks = Array.from({ length: 300 }, (_, index) => ({
          sNo: index + 1,
          rollNo: '',
          questions: questionNumbers.reduce((acc, qNum) => ({ ...acc, [qNum]: '' }), {}),
          totalMarks: 0
        }));
        setMarks(initialMarks);

        // Fetch existing data if any
        const [mappingRes, marksRes] = await Promise.all([
          axios.get(`${API_BASE_URL}/api/end-exam-mapping/fetch`, { params: filters }),
          axios.get(`${API_BASE_URL}/api/end-exam-marks/fetch`, { params: filters })
        ]);

        if (mappingRes.data) {
          setMappings(mappingRes.data.mappings);
        }

        if (marksRes.data) {
          const existingMarks = marksRes.data.marks;
          setMarks(prevMarks => 
            prevMarks.map((row, index) => ({
              ...row,
              ...existingMarks[index]
            }))
          );
        }
      } catch (err) {
        setError('Error fetching data');
        console.error(err);
      }
    };

    fetchCourseOutcomes();
  }, [filters]);

  const handleMappingChange = (questionIndex, coIndex, value) => {
    setMappings(prevMappings => {
      const newMappings = [...prevMappings];
      newMappings[questionIndex].coMappings[coIndex].value = value;
      return newMappings;
    });
  };

  const handleMarkChange = (index, questionNumber, value) => {
    const numValue = value === '' ? '' : Number(value);
    const maxMark = questionNumber.startsWith('1') ? 1 : 5;
    
    // Check if value exceeds max marks
    if (numValue !== '' && numValue > maxMark) {
      alert(`Value cannot exceed maximum marks (${maxMark})`);
      return;
    }

    setMarks(prevMarks => {
      const newMarks = [...prevMarks];
      newMarks[index] = {
        ...newMarks[index],
        questions: {
          ...newMarks[index].questions,
          [questionNumber]: value
        }
      };

      // Calculate total marks
      const total = Object.entries(newMarks[index].questions)
        .reduce((sum, [_, val]) => sum + (val === '' ? 0 : Number(val)), 0);
      newMarks[index].totalMarks = total;

      return newMarks;
    });
  };

  const addMoreRows = () => {
    setMarks(prevMarks => [
      ...prevMarks,
      ...Array.from({ length: 10 }, (_, index) => ({
        sNo: prevMarks.length + index + 1,
        rollNo: '',
        questions: questionNumbers.reduce((acc, qNum) => ({ ...acc, [qNum]: '' }), {}),
        totalMarks: 0
      }))
    ]);
  };

  const saveMapping = async () => {
    try {
      await axios.post(`${API_BASE_URL}/api/end-exam-mapping/save`, {
        ...filters,
        mappings
      });
      alert('End exam mapping saved successfully!');
    } catch (err) {
      setError('Error saving mapping');
      console.error(err);
    }
  };

  const saveMarks = async () => {
    try {
      const validMarks = marks.filter(m => m.rollNo !== '');
      await axios.post(`${API_BASE_URL}/api/end-exam-marks/save`, {
        ...filters,
        marks: validMarks
      });
      alert('End exam marks saved successfully!');
    } catch (err) {
      setError('Error saving marks');
      console.error(err);
    }
  };

  const renderMappingComponent = () => (
    <div className="table-responsive mt-4">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Question</th>
            <th>Maximum Marks</th>
            {courseOutcomes.map(co => (
              <th key={co}>{co}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {mappings.map((mapping, questionIndex) => (
            <tr key={mapping.questionNumber}>
              <td>{mapping.questionNumber}</td>
              <td>{mapping.maxMarks}</td>
              {mapping.coMappings.map((coMapping, coIndex) => (
                <td key={coMapping.coNumber}>
                  <select
                    value={coMapping.value}
                    onChange={(e) => handleMappingChange(questionIndex, coIndex, e.target.value)}
                    className="form-select form-select-sm"
                  >
                    <option value="-">-</option>
                    <option value="1">1</option>
                  </select>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <button className="submit-button" onClick={saveMapping}>
        <b>Save Mapping</b>
      </button>
    </div>
  );

  const renderMarksComponent = () => (
    <div className="table-responsive mt-4">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>S. No.</th>
            <th>Roll No.</th>
            {questionNumbers.map(qNum => (
              <th key={qNum}>{qNum}</th>
            ))}
            <th>Total Marks</th>
          </tr>
          <tr>
            <td colSpan="2">Maximum Marks</td>
            {questionNumbers.map(qNum => (
              <td key={qNum}>{qNum.startsWith('1') ? 1 : 5}</td>
            ))}
            <td>100</td>
          </tr>
        </thead>
        <tbody>
          {marks.map((row, index) => (
            <tr key={index}>
              <td>{row.sNo}</td>
              <td>
                <input
                  type="text"
                  value={row.rollNo}
                  onChange={(e) => handleMarkChange(index, 'rollNo', e.target.value)}
                  className="form-control form-control-sm"
                />
              </td>
              {questionNumbers.map(qNum => (
                <td key={qNum}>
                  <input
                    type="number"
                    value={row.questions[qNum]}
                    onChange={(e) => handleMarkChange(index, qNum, e.target.value)}
                    className="form-control form-control-sm"
                    min="0"
                    max={qNum.startsWith('1') ? 1 : 5}
                  />
                </td>
              ))}
              <td>{row.totalMarks}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="d-flex justify-content-between mt-3">
        <button className="add-button" onClick={addMoreRows}>
          <b>Add More Rows</b>
        </button>
        <button className="submit-button" onClick={saveMarks}>
          <b>Save Marks</b>
        </button>
      </div>
    </div>
  );

  if (!filters.regulation || !filters.semester || !filters.courseName) {
    return <p className="text-center mt-4">Please select all filters to view end exam attainment</p>;
  }

  return (
    <div className="regulation-form mt-4">
      <h5>End Exam Attainment</h5>
      <hr />
      {error && <div className="alert alert-danger">{error}</div>}
      <div className="d-flex gap-2 mb-4">
        <button 
          className={`submit-button ${activeComponent === 'mapping' ? 'active' : ''}`}
          onClick={() => setActiveComponent('mapping')}
        >
          <b>End Exam Mapping</b>
        </button>
        <button 
          className={`submit-button ${activeComponent === 'marks' ? 'active' : ''}`}
          onClick={() => setActiveComponent('marks')}
        >
          <b>End Exam Marks</b>
        </button>
      </div>

      {activeComponent === 'mapping' && renderMappingComponent()}
      {activeComponent === 'marks' && renderMarksComponent()}
    </div>
  );
};

export default EndExamAttainment;