import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

const SubjectiveAttainment = () => {
  const [filters] = useOutletContext();
  const [activeComponent, setActiveComponent] = useState(null);
  const [courseOutcomes, setCourseOutcomes] = useState([]);
  const [mappings, setMappings] = useState([]);
  const [marks, setMarks] = useState([]);
  const [maxMarks, setMaxMarks] = useState({
    subjective1: { Q1: 5, Q2: 5, Q3: 5, Q4: 5, Q5: 5, Q6: 5 },
    subjective2: { Q1: 5, Q2: 5, Q3: 5, Q4: 5, Q5: 5, Q6: 5 }
  });
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCourseOutcomes = async () => {
      if (!filters.regulation || !filters.semester || !filters.courseName) return;

      try {
        const response = await axios.get(`${API_BASE_URL}/api/course-outcomes/fetch`, { params: filters });
        const outcomes = Object.entries(response.data)
          .filter(([key, value]) => key !== '_id' && value.trim() !== '')
          .map(([key]) => key);
        setCourseOutcomes(outcomes);

        // Initialize mappings
        const initialMappings = ['Subjective-1', 'Subjective-2'].map(exam => ({
          examNumber: exam,
          questions: Array.from({ length: 6 }, (_, i) => ({
            questionNumber: `Q${i + 1}`,
            maxMarks: 5,
            coMappings: outcomes.map(co => ({
              coNumber: co,
              value: '-'
            }))
          }))
        }));
        setMappings(initialMappings);

        // Initialize marks with 300 empty rows
        const initialMarks = Array.from({ length: 300 }, (_, index) => ({
          sNo: index + 1,
          rollNo: '',
          subjective1: {
            Q1: '', Q2: '', Q3: '', Q4: '', Q5: '', Q6: ''
          },
          subjective2: {
            Q1: '', Q2: '', Q3: '', Q4: '', Q5: '', Q6: ''
          }
        }));
        setMarks(initialMarks);

        // Fetch existing data if any
        const [mappingRes, marksRes] = await Promise.all([
          axios.get(`${API_BASE_URL}/api/subjective-mapping/fetch`, { params: filters }),
          axios.get(`${API_BASE_URL}/api/subjective-marks/fetch`, { params: filters })
        ]);

        if (mappingRes.data) {
          setMappings(mappingRes.data.mappings);
        }

        if (marksRes.data) {
          const existingMarks = marksRes.data.marks;
          setMarks(prevMarks => 
            prevMarks.map((row, index) => ({
              ...row,
              ...existingMarks[index]
            }))
          );
        }
      } catch (err) {
        setError('Error fetching data');
        console.error(err);
      }
    };

    fetchCourseOutcomes();
  }, [filters]);

  const handleMappingChange = (examIndex, questionIndex, coIndex, value) => {
    setMappings(prevMappings => {
      const newMappings = [...prevMappings];
      newMappings[examIndex].questions[questionIndex].coMappings[coIndex].value = value;
      return newMappings;
    });
  };

  const handleMarkChange = (index, exam, question, value) => {
    const numValue = value === '' ? '' : Number(value);
    
    // Check if value exceeds max marks
    if (numValue !== '') {
      const maxMark = maxMarks[exam][question];
      if (numValue > maxMark) {
        alert(`Value cannot exceed maximum marks (${maxMark})`);
        return;
      }
    }

    setMarks(prevMarks => {
      const newMarks = [...prevMarks];
      newMarks[index] = {
        ...newMarks[index],
        [exam]: {
          ...newMarks[index][exam],
          [question]: value
        }
      };
      return newMarks;
    });
  };

  const addMoreRows = () => {
    setMarks(prevMarks => [
      ...prevMarks,
      ...Array.from({ length: 10 }, (_, index) => ({
        sNo: prevMarks.length + index + 1,
        rollNo: '',
        subjective1: {
          Q1: '', Q2: '', Q3: '', Q4: '', Q5: '', Q6: ''
        },
        subjective2: {
          Q1: '', Q2: '', Q3: '', Q4: '', Q5: '', Q6: ''
        }
      }))
    ]);
  };

  const saveMapping = async () => {
    try {
      await axios.post(`${API_BASE_URL}/api/subjective-mapping/save`, {
        ...filters,
        mappings
      });
      alert('Subjective mapping saved successfully!');
    } catch (err) {
      setError('Error saving mapping');
      console.error(err);
    }
  };

  const saveMarks = async () => {
    try {
      const validMarks = marks.filter(m => m.rollNo !== '');
      await axios.post(`${API_BASE_URL}/api/subjective-marks/save`, {
        ...filters,
        marks: validMarks
      });
      alert('Subjective marks saved successfully!');
    } catch (err) {
      setError('Error saving marks');
      console.error(err);
    }
  };

  const calculateAttainments = () => {
    const validMarks = marks.filter(m => m.rollNo !== '');
    const totalStudents = validMarks.length;
    const questions = ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6'];
    
    const attainments = ['subjective1', 'subjective2'].map(exam => 
      questions.map(q => {
        const maxMark = maxMarks[exam][q];
        const target = maxMark * 0.6;
        
        const studentsAttempted = validMarks.filter(m => m[exam][q] !== '').length;
        const studentsNotAttempted = totalStudents - studentsAttempted;
        const studentsReachingTarget = validMarks.filter(m => 
          m[exam][q] !== '' && Number(m[exam][q]) >= target
        ).length;
        
        const attainmentPercentage = studentsAttempted ? 
          (studentsReachingTarget / studentsAttempted) * 100 : 0;
        
        let attainmentLevel = 0;
        if (attainmentPercentage >= 80) attainmentLevel = 3;
        else if (attainmentPercentage >= 70) attainmentLevel = 2;
        else if (attainmentPercentage >= 60) attainmentLevel = 1;

        return {
          target,
          studentsReachingTarget,
          studentsNotAttempted,
          studentsAttempted,
          attainmentPercentage: attainmentPercentage.toFixed(2),
          attainmentLevel
        };
      })
    );

    return attainments;
  };

  const renderMappingComponent = () => (
    <div className="table-responsive mt-4">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th rowSpan="2">Exam</th>
            <th rowSpan="2">Question</th>
            <th rowSpan="2">Maximum Marks</th>
            {courseOutcomes.map(co => (
              <th key={co}>{co}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {mappings.map((exam, examIndex) => (
            exam.questions.map((question, questionIndex) => (
              <tr key={`${exam.examNumber}-${question.questionNumber}`}>
                {questionIndex === 0 && (
                  <td rowSpan="6">{exam.examNumber}</td>
                )}
                <td>{question.questionNumber}</td>
                <td>{question.maxMarks}</td>
                {question.coMappings.map((coMapping, coIndex) => (
                  <td key={coMapping.coNumber}>
                    <select
                      value={coMapping.value}
                      onChange={(e) => handleMappingChange(examIndex, questionIndex, coIndex, e.target.value)}
                      className="form-select form-select-sm"
                    >
                      <option value="-">-</option>
                      <option value="1">1</option>
                    </select>
                  </td>
                ))}
              </tr>
            ))
          ))}
        </tbody>
      </table>
      <button className="submit-button" onClick={saveMapping}>
        <b>Save Mapping</b>
      </button>
    </div>
  );

  const renderMarksComponent = () => (
    <div className="table-responsive mt-4">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th rowSpan="2">S. No.</th>
            <th rowSpan="2">Roll No.</th>
            <th colSpan="6">Subjective-1</th>
            <th colSpan="6">Subjective-2</th>
          </tr>
          <tr>
            {Array.from({ length: 6 }, (_, i) => `Q${i + 1}`).map(q => (
              <th key={`sub1-${q}`}>{q}</th>
            ))}
            {Array.from({ length: 6 }, (_, i) => `Q${i + 1}`).map(q => (
              <th key={`sub2-${q}`}>{q}</th>
            ))}
          </tr>
          <tr>
            <td colSpan="2">Maximum Marks</td>
            {Object.values(maxMarks.subjective1).map((mark, i) => (
              <td key={`max1-${i}`}>{mark}</td>
            ))}
            {Object.values(maxMarks.subjective2).map((mark, i) => (
              <td key={`max2-${i}`}>{mark}</td>
            ))}
          </tr>
        </thead>
        <tbody>
          {marks.map((row, index) => (
            <tr key={index}>
              <td>{row.sNo}</td>
              <td>
                <input
                  type="text"
                  value={row.rollNo}
                  onChange={(e) => handleMarkChange(index, 'rollNo', null, e.target.value)}
                  className="form-control form-control-sm"
                />
              </td>
              {['subjective1', 'subjective2'].map(exam => (
                Array.from({ length: 6 }, (_, i) => `Q${i + 1}`).map(q => (
                  <td key={`${exam}-${q}`}>
                    <input
                      type="number"
                      value={row[exam][q]}
                      onChange={(e) => handleMarkChange(index, exam, q, e.target.value)}
                      className="form-control form-control-sm"
                      min="0"
                      max={maxMarks[exam][q]}
                    />
                  </td>
                ))
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="d-flex justify-content-between mt-3">
        <button className="add-button" onClick={addMoreRows}>
          <b>Add More Rows</b>
        </button>
        <button className="submit-button" onClick={saveMarks}>
          <b>Save Marks</b>
        </button>
      </div>
    </div>
  );

  const renderAttainmentsComponent = () => {
    const attainments = calculateAttainments();
    const questions = ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6'];
    
    return (
      <div className="table-responsive mt-4">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Criteria</th>
              {['Subjective-1', 'Subjective-2'].map(exam => (
                questions.map(q => (
                  <th key={`${exam}-${q}`}>{`${exam} ${q}`}</th>
                ))
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Target for Subjective</td>
              {attainments.flat().map((a, i) => (
                <td key={`target-${i}`}>{a.target}</td>
              ))}
            </tr>
            <tr>
              <td>No. of students reaching target</td>
              {attainments.flat().map((a, i) => (
                <td key={`reaching-${i}`}>{a.studentsReachingTarget}</td>
              ))}
            </tr>
            <tr>
              <td>No. of students who didn't attempt</td>
              {attainments.flat().map((a, i) => (
                <td key={`not-attempted-${i}`}>{a.studentsNotAttempted}</td>
              ))}
            </tr>
            <tr>
              <td>No. of students who attempted</td>
              {attainments.flat().map((a, i) => (
                <td key={`attempted-${i}`}>{a.studentsAttempted}</td>
              ))}
            </tr>
            <tr>
              <td>Attainment %</td>
              {attainments.flat().map((a, i) => (
                <td key={`percentage-${i}`}>{a.attainmentPercentage}%</td>
              ))}
            </tr>
            <tr>
              <td>Attainment Level</td>
              {attainments.flat().map((a, i) => (
                <td key={`level-${i}`}>{a.attainmentLevel}</td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    );
  };

  if (!filters.regulation || !filters.semester || !filters.courseName) {
    return <p className="text-center mt-4">Please select all filters to view subjective attainment</p>;
  }

  return (
    <div className="regulation-form mt-4">
      <h5>Subjective Attainment</h5>
      <hr />
      {error && <div className="alert alert-danger">{error}</div>}
      <div className="d-flex gap-2 mb-4">
        <button 
          className={`submit-button ${activeComponent === 'mapping' ? 'active' : ''}`}
          onClick={() => setActiveComponent('mapping')}
        >
          <b>Subjective Mapping</b>
        </button>
        <button 
          className={`submit-button ${activeComponent === 'marks' ? 'active' : ''}`}
          onClick={() => setActiveComponent('marks')}
        >
          <b>Subjective Marks</b>
        </button>
        <button 
          className={`submit-button ${activeComponent === 'attainments' ? 'active' : ''}`}
          onClick={() => setActiveComponent('attainments')}
        >
          <b>Print Subjective Attainments</b>
        </button>
      </div>

      {activeComponent === 'mapping' && renderMappingComponent()}
      {activeComponent === 'marks' && renderMarksComponent()}
      {activeComponent === 'attainments' && renderAttainmentsComponent()}
    </div>
  );
};

export default SubjectiveAttainment;